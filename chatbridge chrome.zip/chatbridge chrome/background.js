﻿chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'EXPORT_FILE') {
    let turnsData = request.data;
    const siteName = request.siteName;
    const date = new Date();
    const pad = (n) => n.toString().padStart(2, '0');
    const dateStr = `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}`;
    const filename = `${siteName} - ${dateStr}.html`;

    if (typeof turnsData === 'string') {
      turnsData = [{ role: 'unknown', text: turnsData }];
    }

    let htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Chat Export - ${siteName}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 40px auto; padding: 20px; background: #f9f9f9; }
    h1 { text-align: center; color: #1a1a1a; border-bottom: 2px solid #ddd; padding-bottom: 10px; }
    .turn { margin-bottom: 25px; padding: 15px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
    .user-turn { background: #e8f5e9; border-left: 5px solid #2e7d32; }
    .assistant-turn { background: #ffebee; border-left: 5px solid #c62828; }
    .unknown-turn { background: #f5f5f5; border-left: 5px solid #999; }
    .role { font-weight: bold; font-size: 14px; margin-bottom: 8px; text-transform: uppercase; }
    .user-turn .role { color: #2e7d32; }
    .assistant-turn .role { color: #c62828; }
    .unknown-turn .role { color: #999; }
    .content { font-size: 15px; white-space: pre-wrap; word-wrap: break-word; }
  </style>
</head>
<body>
  <h1>${siteName} Chat Export</h1>
  <p style="text-align:center; color:#666;">Exported on ${dateStr}</p>
`;

    turnsData.forEach(turn => {
      const roleClass = turn.role === 'user' ? 'user-turn' : (turn.role === 'assistant' ? 'assistant-turn' : 'unknown-turn');
      const roleName = turn.role === 'user' ? 'User' : (turn.role === 'assistant' ? 'Assistant' : 'Message');
      const escapedText = turn.text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
      htmlContent += `<div class="turn ${roleClass}"><div class="role">${roleName}</div><div class="content">${escapedText}</div></div>`;
    });

    htmlContent += `</body></html>`;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const reader = new FileReader();
    reader.onload = function() {
      chrome.downloads.download({ url: reader.result, filename: filename, saveAs: false });
    };
    reader.readAsDataURL(blob);
    sendResponse({ success: true });
  }

  if (request.type === 'EXPORT_TO_SITE') {
    const { data, target } = request;
    chrome.storage.local.set({ chatbridge_temp_text: data }, () => {
      chrome.tabs.create({ url: target.url }, (newTab) => {
        const tabId = newTab.id;
        chrome.tabs.onUpdated.addListener(function listener(tabIdUpdated, changeInfo, tab) {
          if (tabIdUpdated === tabId && changeInfo.status === 'complete') {
            chrome.tabs.onUpdated.removeListener(listener);
            chrome.storage.local.get(['chatbridge_temp_text'], (result) => {
              const storedData = result.chatbridge_temp_text;
              if (!storedData) return;
              
              const injectorFile = target.custom ? 'custom.js' : `${target.key}.js`;
              
              chrome.scripting.executeScript({
                target: { tabId: tabId },
                files: [`injectors/${injectorFile}`]
              }).then(() => {
                return chrome.scripting.executeScript({
                  target: { tabId: tabId },
                  func: (data) => { 
                    const instruction = `Here is our conversation so far, please continue from here:\n\n`;
                    let plainText = instruction;
                    if (Array.isArray(data)) {
                      data.forEach(turn => {
                        plainText += (turn.role === 'user' ? 'User:' : (turn.role === 'assistant' ? 'Assistant:' : 'Message:')) + '\n' + turn.text + '\n\n';
                      });
                    } else {
                      plainText += data;
                    }
                    window.chatbridgeInject(plainText); 
                  },
                  args: [storedData]
                });
              }).then(() => {
                chrome.storage.local.remove('chatbridge_temp_text');
              }).catch(err => console.error('ChatBridge injection failed:', err));
            });
          }
        });
      });
    });
    sendResponse({ success: true });
  }
  return true;
});
