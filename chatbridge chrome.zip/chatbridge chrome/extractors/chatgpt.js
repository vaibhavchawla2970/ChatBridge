﻿window.chatbridgeExtract = function() {
  try {
    let container = document.querySelector('main, [class*="chat-container"], [class*="conversation"], [role="main"], [class*="app-container"]');
    if (!container) container = document.body;
    
    const clone = container.cloneNode(true);
    clone.querySelectorAll('button, svg, [aria-hidden="true"], header, footer, nav, input, textarea, form, script, style').forEach(el => el.remove());
    
    const turns = clone.querySelectorAll('[data-message-author-role], [data-testid*="message"], user-query, model-response, [class*="message"], [class*="turn"], [role="article"], [class*="bubble"], [class*="ds-message"]');
    
    let turnsData = [];
    
    if (turns.length > 0) {
      turns.forEach(turn => {
        let text = turn.innerText.trim();
        if (!text) return;
        
        let role = turn.getAttribute('data-message-author-role') || turn.getAttribute('data-role');
        if (!role) {
          const cls = (turn.className || '').toLowerCase();
          const tag = turn.tagName.toLowerCase();
          if (cls.includes('user') || cls.includes('human') || tag === 'user-query') role = 'user';
          else if (cls.includes('assistant') || cls.includes('model') || cls.includes('bot') || tag === 'model-response') role = 'assistant';
          else role = 'unknown';
        }
        
        turnsData.push({ role: role, text: text });
      });
    }
    
    if (turnsData.length === 0) {
      const text = clone.innerText.trim();
      if (text) {
        text.split(/\n\n+/).forEach(block => turnsData.push({ role: 'unknown', text: block.trim() }));
      } else {
        return "DEBUG_ERROR: Container found, but it has no innerText.";
      }
    }
    
    return turnsData;
  } catch (e) {
    return "DEBUG_ERROR: " + e.message;
  }
};
