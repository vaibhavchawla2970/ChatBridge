﻿window.chatbridgeInject = function(text) {
  const findAndInject = () => {
    const inputDiv = document.querySelector('div[contenteditable="true"]');
    const inputTextarea = document.querySelector('textarea');
    
    if (inputTextarea) {
      inputTextarea.focus();
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
      nativeInputValueSetter.call(inputTextarea, text);
      inputTextarea.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    } else if (inputDiv) {
      inputDiv.focus();
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, text);
      return true;
    }
    return false;
  };
  let attempts = 0;
  const interval = setInterval(() => {
    if (findAndInject() || attempts >= 60) { clearInterval(interval); } // 12 seconds timeout
    attempts++;
  }, 200);
};
