﻿window.chatbridgeInject = function(text) {
  const findAndInject = () => {
    const input = document.querySelector('div[contenteditable="true"]');
    if (input) {
      input.focus();
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, text);
      return true;
    }
    return false;
  };
  let attempts = 0;
  const interval = setInterval(() => {
    if (findAndInject() || attempts >= 60) { clearInterval(interval); }
    attempts++;
  }, 200);
};
