const defaultSites = [
  { key: 'claude', name: 'Claude', url: 'https://claude.ai/new', domain: 'claude.ai', custom: false },
  { key: 'chatgpt', name: 'ChatGPT', url: 'https://chatgpt.com/', domain: 'chatgpt.com', custom: false },
  { key: 'gemini', name: 'Gemini', url: 'https://gemini.google.com/app', domain: 'gemini.google.com', custom: false },
  { key: 'grok', name: 'Grok', url: 'https://grok.com/', domain: 'grok.com', custom: false },
  { key: 'zai', name: 'Z.ai', url: 'https://chat.z.ai/', domain: 'chat.z.ai', custom: false },
  { key: 'deepseek', name: 'DeepSeek', url: 'https://chat.deepseek.com/', domain: 'chat.deepseek.com', custom: false },
  { key: 'copilot', name: 'Copilot', url: 'https://copilot.microsoft.com/', domain: 'copilot.microsoft.com', custom: false },
  { key: 'perplexity', name: 'Perplexity', url: 'https://www.perplexity.ai/', domain: 'perplexity.ai', custom: false },
  { key: 'mistral', name: 'Mistral', url: 'https://chat.mistral.ai/', domain: 'chat.mistral.ai', custom: false }
];

let activeTab = null;
let currentSite = null;
let customSites = [];

function fadeIn(element) {
  element.style.display = 'flex';
  element.style.opacity = '0';
  element.style.transform = 'translateY(4px)';
  element.offsetHeight;
  element.style.transition = 'opacity 0.15s ease-out, transform 0.15s ease-out';
  element.style.opacity = '1';
  element.style.transform = 'translateY(0)';
}

function fadeOut(element, callback) {
  element.style.transition = 'opacity 0.15s ease-out, transform 0.15s ease-out';
  element.style.opacity = '0';
  element.style.transform = 'translateY(-4px)';
  setTimeout(() => {
    element.style.display = 'none';
    if (callback) callback();
  }, 150);
}

document.addEventListener('DOMContentLoaded', () => {
  const detectedLabel = document.getElementById('detected-label');
  const siteButtons = document.getElementById('site-buttons');
  const saveBtn = document.getElementById('save-file');
  const errorMsg = document.getElementById('error-msg');
  const loading = document.getElementById('loading');
  const unsupportedMsg = document.getElementById('unsupported-msg');
  const addBtn = document.getElementById('add-btn');
  const addForm = document.getElementById('add-form');
  const customName = document.getElementById('custom-name');
  const customUrl = document.getElementById('custom-url');
  const saveCustom = document.getElementById('save-custom');
  const cancelCustom = document.getElementById('cancel-custom');

  chrome.storage.local.get(['chatbridge_custom_sites'], (result) => {
    customSites = result.chatbridge_custom_sites || [];
    initUI();
  });

  function initUI() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      activeTab = tabs[0];
      const url = activeTab.url || '';
      currentSite = null;

      for (const site of defaultSites) {
        if (url.includes(site.domain)) { currentSite = site; break; }
      }
      if (!currentSite) {
        for (const site of customSites) {
          try {
            if (url.includes(new URL(site.url).hostname)) { currentSite = site; break; }
          } catch(e) {}
        }
      }

      if (!currentSite) {
        detectedLabel.style.display = 'none';
        saveBtn.style.display = 'none';
        siteButtons.style.display = 'none';
        fadeIn(unsupportedMsg);
        return;
      }

      detectedLabel.querySelector('.label-text').innerText = `Detected: ${currentSite.name}`;
      fadeIn(detectedLabel);
      fadeIn(saveBtn);
      fadeIn(siteButtons);
      renderButtons();
    });
  }

  function renderButtons() {
    siteButtons.innerHTML = '';
    let allSites = [...defaultSites, ...customSites];
    allSites.forEach(site => {
      if (site.key === currentSite.key || site.url === currentSite.url) return;
      const btn = document.createElement('button');
      btn.className = `btn btn-secondary ai-${site.key}`;
      btn.setAttribute('role', 'listitem');
      btn.setAttribute('aria-label', `Export to ${site.name}`);
      btn.innerHTML = `<span>${site.name}</span>`;
      btn.addEventListener('click', () => handleAction('EXPORT_TO_SITE', currentSite, site));
      siteButtons.appendChild(btn);
    });
  }

  addBtn.addEventListener('click', () => {
    const isOpen = addForm.style.display !== 'none';
    if (isOpen) {
      fadeOut(addForm);
      customName.value = '';
      customUrl.value = '';
    } else {
      fadeIn(addForm);
      customName.focus();
    }
  });

  cancelCustom.addEventListener('click', () => {
    fadeOut(addForm);
    customName.value = '';
    customUrl.value = '';
  });

  customUrl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') saveCustom.click();
    if (e.key === 'Escape') cancelCustom.click();
  });

  customName.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') cancelCustom.click();
  });

  saveCustom.addEventListener('click', () => {
    const name = customName.value.trim();
    let url = customUrl.value.trim();
    if (!name || !url) return;
    if (!url.startsWith('http')) url = 'https://' + url;

    try {
      new URL(url);
    } catch (e) {
      errorMsg.innerText = "Invalid URL. Please include https://";
      fadeIn(errorMsg);
      return;
    }

    const newSite = { key: 'custom_' + Date.now(), name: name, url: url, custom: true };
    customSites.push(newSite);
    chrome.storage.local.set({ chatbridge_custom_sites: customSites }, () => {
      fadeOut(addForm, () => {
        customName.value = '';
        customUrl.value = '';
        renderButtons();
      });
    });
  });

  saveBtn.addEventListener('click', () => handleAction('EXPORT_FILE', currentSite, null));

  function handleAction(action, fromSite, toSite) {
    errorMsg.style.display = 'none';
    loading.style.display = 'none';

    fadeIn(loading);

    const extractorFile = fromSite.custom ? 'universal.js' : `${fromSite.key}.js`;

    chrome.scripting.executeScript({
      target: { tabId: activeTab.id },
      files: [`extractors/${extractorFile}`]
    }).then(() => {
      return chrome.scripting.executeScript({
        target: { tabId: activeTab.id },
        func: () => window.chatbridgeExtract()
      });
    }).then((results) => {
      fadeOut(loading);
      const text = results && results[0] && results[0].result;

      if (!text || (typeof text === 'string' && text.startsWith("DEBUG_ERROR:"))) {
        const errorText = text ? text.replace("DEBUG_ERROR: ", "") : "Couldn't read this chat. Try refreshing.";
        errorMsg.innerText = errorText;
        fadeIn(errorMsg);
        return;
      }

      if (action === 'EXPORT_FILE') {
        chrome.runtime.sendMessage({ type: 'EXPORT_FILE', data: text, siteName: fromSite.name }, () => window.close());
      } else if (action === 'EXPORT_TO_SITE') {
        chrome.runtime.sendMessage({ type: 'EXPORT_TO_SITE', data: text, target: toSite }, () => window.close());
      }
    }).catch(err => {
      fadeOut(loading);
      errorMsg.innerText = "Error: " + err.message;
      fadeIn(errorMsg);
    });
  }
});
